#pragma once

namespace GParsing {
namespace HTTP {
enum MessageType { Request, Response };
enum RequestType { UNKOWN, GET, POST, HEAD };
} // namespace HTTP
} // namespace GParsing
